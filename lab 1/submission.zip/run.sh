g++ uninformed_search.cpp
./a.out $1 > output.txt
