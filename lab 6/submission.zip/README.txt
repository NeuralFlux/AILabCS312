Execute: ./run.sh <path-to-input> <mode-of-heuristic-('u' or 'o')>
