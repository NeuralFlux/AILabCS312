g++ AO_star.cpp;
./a.out $1 $2;
