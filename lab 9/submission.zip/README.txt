To run, do
./run.sh <path_to_input> <path_to_desired_output>
