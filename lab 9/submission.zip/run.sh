python3 GSP.py $1 $2
