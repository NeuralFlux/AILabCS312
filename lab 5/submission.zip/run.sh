g++ A_star.cpp
./a.out $1
