g++ code.cpp
./a.out $1
