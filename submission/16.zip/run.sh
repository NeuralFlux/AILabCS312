python3 tsp_comp.py $1
