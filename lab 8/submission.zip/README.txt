To run,
./run.sh <path_to_input>

Few test inputs which were used for the report experiments are given

---- Parameters to Control ----
# grid_size - size of the environment (grid_size x grid_size)
# p_err - probability of error in communication [Basically probability of desired action changing to a different one]
# d_pen - penalty of stepping on a detector plate
# fin_rew - final reward for reaching goal (after this, game exits)
# step_pen - penalty on each step
