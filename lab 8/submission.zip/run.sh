python3 MDPSolver.py $1
