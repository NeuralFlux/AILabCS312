g++ lab3.cpp
./a.out $1 $2
