Kindly build the project before running it. We have deleted the object files as Moodle wasn't accepting submissions of size more than 1MB.

